-- SQLite
-- First classifying using the required cases as asked in the problem statement

-- And grouped by class and used count() to get required output.
-- That is class count.
WITH classification(TrackId, Name, class) AS(
SELECT TrackId, Name,
CASE
WHEN Milliseconds<60000 THEN 'short'
WHEN Milliseconds>300000 THEN 'long'
ELSE 'medium'
end class
from tracks) 
SELECT class, count(class) as count
FROM classification
GROUP BY class;

-- And the details of each track are:

SELECT TrackId, Name,Milliseconds,
CASE
WHEN Milliseconds<60000 THEN 'short'
WHEN Milliseconds>300000 THEN 'long'
ELSE 'medium'
end class
from tracks;