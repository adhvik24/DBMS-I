-- SQLite
-- SQLite
-- Used substr to extract first character from each entry of name
-- count() is used to count the number of entry in each group of the grouped tuple.
SELECT substr(Name,1,1) as firstchar, count(Name) as count_name
-- LEFT OUTER JOIN is used to acheive the required condition using ArtistId
-- and grouped by first character of artist name.
FROM artists LEFT OUTER JOIN albums USING (ArtistId)
GROUP BY firstchar;
