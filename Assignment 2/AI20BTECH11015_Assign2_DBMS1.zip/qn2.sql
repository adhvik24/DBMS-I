/*SQLite*/
/*create into the instructor table*/
CREATE TABLE instructor (
name TEXT,
course_id TEXT
);
/*insert data into the instructor table*/
INSERT INTO instructor (name, course_id)
VALUES ('Amy','CS1000'), ('Aaron','CS700'), ('Anne','CS400');
-- create student table
CREATE TABLE student (
name TEXT,
course_id TEXT
);
/*insert data into the student table*/
INSERT INTO student (name, course_id)
VALUES
('Jack','CS800'),
('Jones','CS1000'),
('Jason', 'CS450');
--  Verifying that the tables setup correctly and that the data is populated correctly.
SELECT *
FROM instructor;
SELECT *
FROM student;
/*Writing a query that "emulates" a FULL OUTER JOIN on the student and
instructor tables listing the instructor's name, the course they teach, the
student's name, and the course they take.
using LEFT OUTER JOIN to implement FULL OUTER JOIN.
without using FULL OUTER JOIN.*/

SELECT instructor.name as ins_name,instructor.course_id as ins_teach,student.name as stu_name,student.course_id as stu_take
FROM instructor LEFT OUTER JOIN student 
ON instructor.course_id=student.course_id
UNION
SELECT instructor.name,instructor.course_id,student.name,student.course_id  
FROM student LEFT OUTER JOIN instructor
ON instructor.course_id=student.course_id;
drop table instructor;
drop table student;



