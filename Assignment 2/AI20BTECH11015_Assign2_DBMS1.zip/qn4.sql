--SQLite
-- Creating required tables.
create table X (
id_num integer,
id_str text
);
-- Inserting required data into the table created.
insert into X (id_num, id_str)
values
(1,'A'),
(2,'B'),
(3,'C'),
(4,'D'),
(5,'E');
-- Checking whether the  table is created and data is populated correctly.
SELECT * FROM X;
-- Concatenating the strings with commas on a condition that id_num are in ascending order.
SELECT (y1.id_num||','||y2.id_num||','||y3.id_num) as num_ids, (y1.id_str||','||y2.id_str||','||y3.id_str) as str_ids
FROM X AS y1, X AS y2, X AS y3
WHERE y1.id_num<y2.id_num AND y2.id_num<y3.id_num;
drop table X;